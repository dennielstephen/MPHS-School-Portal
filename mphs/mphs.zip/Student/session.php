<?php

	session_start();
	
	require_once 'class.user.php';
	$session = new USER();
	
?>
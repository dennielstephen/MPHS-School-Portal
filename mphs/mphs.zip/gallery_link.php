	<script src="js/jquery.slider.bundle.js"></script>
	<script src="js/jquery.slider.js"></script>
	<link href="css/bootstrap.css" media="screen" rel="stylesheet">
	<link rel="stylesheet" href="css/jslider.css">